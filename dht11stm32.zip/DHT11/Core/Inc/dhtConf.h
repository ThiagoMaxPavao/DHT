#ifndef _DHT_CONF_H
#define _DHT_CONF_H

#define     _DHT_USE_FREERTOS       0

#endif
